    //https://konvajs.github.io/docs/sandbox/Modify_Curves_with_Anchor_Points.html
    var width = window.innerWidth;
    var height = window.innerHeight;

    // globals
    var curveLayer, lineLayer, anchorLayer, quad, bezier, xLayer, anchorXLayer, Y1, y1Layer;

    function updateDottedLines() {
        var q = quad;
        // var b = bezier;

        var quadLine = lineLayer.get('#quadLine')[0];
        // var bezierLine = lineLayer.get('#bezierLine')[0];

        quadLine.setPoints([q.start.attrs.x, q.start.attrs.y, q.control.attrs.x, q.control.attrs.y, q.end.attrs.x, q.end.attrs.y]);

        // bezierLine.setPoints([b.start.attrs.x, b.start.attrs.y, b.control1.attrs.x, b.control1.attrs.y, b.control2.attrs.x, b.control2.attrs.y, b.end.attrs.x, b.end.attrs.y]);
        lineLayer.draw();
    }

    function updateXLines() {

        var q = quad;
        var xLine = xLayer.get('#xLine')[0];
        // var bezierLine = lineLayer.get('#bezierLine')[0];

        xLine.setPoints([q.start.attrs.x, q.start.attrs.y, q.end.attrs.x, q.start.attrs.y]);

        // bezierLine.setPoints([b.start.attrs.x, b.start.attrs.y, b.control1.attrs.x, b.control1.attrs.y, b.control2.attrs.x, b.control2.attrs.y, b.end.attrs.x, b.end.attrs.y]);
        xLayer.draw();
    }

    function updateYPoint() {

        var q = quad;
        var Y1 = anchorXLayer.get('#xAnchor')[0];
        // var bezierLine = lineLayer.get('#bezierLine')[0];

        Y1.setAttr("y",q.start.attrs.y);

        // bezierLine.setPoints([b.start.attrs.x, b.start.attrs.y, b.control1.attrs.x, b.control1.attrs.y, b.control2.attrs.x, b.control2.attrs.y, b.end.attrs.x, b.end.attrs.y]);
        anchorXLayer.draw();
    }

    function buildAnchor(x, y) {

        var anchor = new Konva.Circle({
            x: x,
            y: y,
            radius: 5,
            stroke: '#666',
            fill: '#ddd',
            strokeWidth: 2,
            draggable: true
        });

        // add hover styling
        anchor.on('mouseover', function() {
            document.body.style.cursor = 'pointer';
            this.setStrokeWidth(4);
            anchorLayer.draw();
            anchorXLayer.draw();

        });
        anchor.on('mouseout', function() {
            document.body.style.cursor = 'default';
            this.setStrokeWidth(2);
            anchorLayer.draw();
            anchorXLayer.draw();

        });

        anchor.on('dragend', function() {
            drawCurves();
            updateDottedLines();
            updateYPoint();
            updateXLines();
        });

        anchorLayer.add(anchor);
        return anchor;
    }

    function buildXAnchor(x, y) {

        var anchor = new Konva.Circle({
            x: x,
            y: y,
            radius: 5,
            stroke: '#666',
            fill: '#ddd',
            strokeWidth: 2,
            draggable: true,
            id : "xAnchor",
            dragBoundFunc: function(pos) {
                return {
                    x: pos.x,
                    y: quad.start.attrs.y
                }
            }
        });

        // add hover styling
        anchor.on('mouseover', function() {
            document.body.style.cursor = 'pointer';
            this.setStrokeWidth(4);
            anchorXLayer.draw();
        });
        anchor.on('mouseout', function() {
            document.body.style.cursor = 'default';
            this.setStrokeWidth(2);
            anchorXLayer.draw();

        });

        anchor.on('dragend', function() {
            drawCurves();
            // updateYPoint();
        });

        anchorXLayer.add(anchor);
        return anchor;
    }

    function drawCurves() {
        var context = curveLayer.getContext();

        context.clear();

        console.log("start=("+quad.start.attrs.x+","+quad.start.attrs.y+")");
        console.log("control=("+quad.control.attrs.x+","+quad.control.attrs.y+")");
        console.log("end=("+quad.end.attrs.x+","+quad.end.attrs.y+")");


        var bezier = [
            [quad.start.attrs.x, quad.start.attrs.y],
            [quad.control.attrs.x, quad.control.attrs.y],
            [quad.end.attrs.x, quad.end.attrs.y]
        ];

        var point = de.casteljau(bezier,
            //value between 0 and 1, 0 - the beginning of the curve, 1 - the end
            0.5
        );


        context.beginPath();
        context.arc(point[0], point[1], 5, 0, 2 * Math.PI, false);
        context.fillStyle = 'Thistle    ';
        context.fill();
        context.lineWidth = 2;
        context.strokeStyle = 'Thistle    ';
        context.stroke();

        var p = YBX2({x:quad.start.attrs.x,y:quad.start.attrs.y}
            ,{x:quad.control.attrs.x,y:quad.control.attrs.y}
           ,{x:quad.end.attrs.x,y:quad.end.attrs.y}
            ,Y1.p.attrs.x
            ,{x:quad.start.attrs.x,y:quad.start.attrs.y}
            ,{x:quad.control.attrs.x,y:quad.control.attrs.y}
            ,{x:quad.end.attrs.x,y:quad.end.attrs.y}); 


        context.beginPath();
        context.moveTo(p.x, p.y);
        context.lineTo(Y1.p.attrs.x, Y1.p.attrs.y);
        context.lineWidth = 1;
        context.opacity=.01;
        context.strokeStyle = 'Thistle   ';
        context.stroke();

        context.beginPath();
        context.arc(p.x, p.y, 5, 0, 2 * Math.PI, false);
        context.fillStyle = 'SlateBlue   ';
        context.fill();
        context.lineWidth = 2;
        context.strokeStyle = 'SlateBlue   ';
        context.stroke();

        console.log("p.x="+p.x + "p.y="+p.y);
        console.log("point="+point);
  

        var dividedBezier = de.divideBezierCurve(bezier, 0.5);
        
        var b1 = dividedBezier[0],
            b2 = dividedBezier[1];


        console.log("b1="+b1);
        console.log("b2="+b2);
        
        context.beginPath();
        context.arc(b1[1][0], b1[1][1], 2, 0, 2 * Math.PI, false);
        context.fillStyle = 'gray   ';
        context.fill();
        context.lineWidth = 2;
        context.strokeStyle = 'gray   ';
        context.stroke();

        context.beginPath();
        context.arc(b2[1][0], b2[1][1], 2, 0, 2 * Math.PI, false);
        context.fillStyle = 'gray   ';
        context.fill();
        context.lineWidth = 2;
        context.strokeStyle = 'gray   ';
        context.stroke();

        var oX = Math.round(p.x - quad.start.attrs.x);
        context.beginPath();
        context.font = '12px Calibri';
        context.fillText("x="+oX, p.x - 15 , Y1.p.attrs.y - 12);
        context.stroke();

        /*
        context.save();
        var oY = Math.round(p.y - Y1.p.attrs.y)*-1;
        //context.beginPath();
        //context.font = '12px Calibri';
        //context.translate(400, 400);
        context.rotate(-5*Math.PI/180);
        context.fillText("y="+oY, p.x + 10 , p.y + 10);
        //context.stroke();
        context.restore();
        */

       var ty1 = YBX2({x:quad.start.attrs.x,y:quad.start.attrs.y}
        ,{x:quad.control.attrs.x,y:quad.control.attrs.y}
       ,{x:quad.end.attrs.x,y:quad.end.attrs.y}
        ,Y1.p.attrs.x -30
        ,{x:quad.start.attrs.x,y:quad.start.attrs.y}
        ,{x:quad.control.attrs.x,y:quad.control.attrs.y}
        ,{x:quad.end.attrs.x,y:quad.end.attrs.y}); 

        var ty2 = YBX2({x:quad.start.attrs.x,y:quad.start.attrs.y}
            ,{x:quad.control.attrs.x,y:quad.control.attrs.y}
           ,{x:quad.end.attrs.x,y:quad.end.attrs.y}
            ,Y1.p.attrs.x +30
            ,{x:quad.start.attrs.x,y:quad.start.attrs.y}
            ,{x:quad.control.attrs.x,y:quad.control.attrs.y}
            ,{x:quad.end.attrs.x,y:quad.end.attrs.y}); 

        var oY2 = Math.round((p.y - Y1.p.attrs.y)*100)/100*-1;
        var oY = Number.parseFloat(oY2).toFixed(2).toLocaleString();
        var y1Text = y1Layer.get('#y1Text')[0];
        y1Text.setAttr("text", "y="+oY);
        var py1 = 'M'+(ty1.x+10)+','+(ty1.y+12)+' '+(ty2.x+10)+','+(ty2.y+12);
        y1Text.setAttr("data", py1);
        y1Layer.draw();



//--------------------



        // draw quad
        context.beginPath();
        context.moveTo(quad.start.attrs.x, quad.start.attrs.y);
        context.quadraticCurveTo(quad.control.attrs.x, quad.control.attrs.y, quad.end.attrs.x, quad.end.attrs.y);
        context.setAttr('strokeStyle', 'red');
        context.setAttr('lineWidth', 4);
        context.stroke();

        
        // draw bezier
        // context.beginPath();
        // context.moveTo(bezier.start.attrs.x, bezier.start.attrs.y);
        // context.bezierCurveTo(bezier.control1.attrs.x, bezier.control1.attrs.y, bezier.control2.attrs.x, bezier.control2.attrs.y, bezier.end.attrs.x, bezier.end.attrs.y);
        // context.setAttr('strokeStyle', 'blue');
        // context.setAttr('lineWidth', 4);
        // context.stroke();



    }

    var stage = new Konva.Stage({
        container: 'container',
        width: width,
        height: height
    });

    anchorLayer = new Konva.Layer();
    anchorXLayer = new Konva.Layer();
    lineLayer = new Konva.Layer();
    xLayer = new Konva.Layer();


    // curveLayer just contains a canvas which is drawn
    // onto with the existing canvas API
    curveLayer = new Konva.Layer();

    var quadLine = new Konva.Line({
        dash: [10, 10, 0, 10],
        strokeWidth: 1,
        stroke: 'black',
        lineCap: 'round',
        id: 'quadLine',
        opacity: 0.3,
        points: [0, 0]
    });

    // var bezierLine = new Konva.Line({
    //     dash: [10, 10, 0, 10],
    //     strokeWidth: 3,
    //     stroke: 'black',
    //     lineCap: 'round',
    //     id: 'bezierLine',
    //     opacity: 0.3,
    //     points: [0, 0]
    // });

    // add dotted line connectors
    lineLayer.add(quadLine);
    // lineLayer.add(bezierLine);

    quad = {
        start: buildAnchor(width/4, height/1.5),
        control: buildAnchor(width/3, height/3),
        end: buildAnchor(width/1.5, height/4)
    };

    Y1 = {
        p: buildXAnchor(width/3.2, height/1.5)
    };

    // var xAnchor = new Konva.Circle({
    //     x: x,
    //     y: y,
    //     radius: 5,
    //     stroke: '#666',
    //     fill: '#ddd',
    //     strokeWidth: 2,
    //     draggable: true
    // });
    // buildXAnchor(10, 500);



    var xLine = new Konva.Line({
        strokeWidth: 2,
        stroke: 'gray',
        lineCap: 'round',
        id: 'xLine',
        opacity: 1
    });

    xLayer.add(xLine);


    // bezier = {
    //     start: buildAnchor(280, 20),
    //     control1: buildAnchor(530, 40),
    //     control2: buildAnchor(480, 150),
    //     end: buildAnchor(300, 150)
    // };


    
    // keep curves insync with the lines
    anchorLayer.on('beforeDraw', function() {
        drawCurves();
        updateDottedLines();
        updateYPoint();
        updateXLines();
    });

    anchorXLayer.on('beforeDraw', function() {
        drawCurves();
        // updateYPoint();
    });

    var textLayer = new Konva.Layer();
    var complexText = new Konva.Text({
        x: 10,
        y: 10,
        //data: 'M100,300 C150,100 200,50 500,60',
        text: 'COURBE DE B\u00c9ZIER D\u00c9MO\nCanvas API HTML5 standard.\nKonva.js - HTML5 2d canvas library for desktop and mobile applications.\ndecasteljau.js - Recursive implementation of de Casteljau algorithm.',
        fontSize: 16,
        fontFamily: 'Calibri',
        fill: '#555',
        width: width,
        padding: 0,
        align: 'left'
      });

    textLayer.add(complexText);

    y1Layer = new Konva.Layer();
    var p = "M100,500 C300,300";
    var y = 150; 
    var y1Text = new Konva.TextPath({
        data: 'M100,300 C150,100 200,50 500,60',
        text: "y="+y,
        fontSize: 12,
        fontFamily: 'Calibri',
        fill: '#555',
        width: width,
        padding: 0,
        opacity:.8,
        align: 'left',
        id:"y1Text"
      });
    y1Layer.add(y1Text);
    stage.add(y1Layer);

    stage.add(xLayer);
    stage.add(textLayer);
    stage.add(curveLayer);
    stage.add(lineLayer);
    stage.add(anchorLayer);
    stage.add(anchorXLayer);

    drawCurves();
    updateDottedLines();
    updateXLines();
    updateYPoint();

function solve(a, b, c) {
    var result = (-1 * b + Math.sqrt(Math.pow(b, 2) - (4 * a * c))) / (2 * a);
    // var result2 = (-1 * b - Math.sqrt(Math.pow(b, 2) - (4 * a * c))) / (2 * a);
    return result/* + "<br>" + result2*/;
}

function YBX2(a,b,c,x, p0,c0,p1){

    a = a.x;
    b = b.x;
    c = c.x;

    var A = a - 2*b + c,
    B = -2*a + 2*b,
    C = a-x;
    
    t = solve(A, B, C);

    var p = Bezier2(p0,c0,p1,t);
    return p;
}

function Bezier2 (a,b,c,t) {

    var point = {x:0,y:0},
        mt  = 1-t,
        mt2 = mt*mt;

    //t = 0.5; // given example value
    point.x = (1 - t) * (1 - t) * a.x + 2 * (1 - t) * t * b.x + t * t * c.x;
    point.y = (1 - t) * (1 - t) * a.y + 2 * (1 - t) * t * b.y + t * t * c.y;

    return point;
}


/*
 * http://jsfiddle.net/uz31b1yx/86/
 * Get new x,y on curve by given x
 * @params a,b,c,d {x:x,y:y}
 * @params x 
 * @return {{x:new x on cruve ,y: new y on cruve}}
 */
function YBX(a,b,c,d,x, p0,c0,c1,p1){
	
    a = a.x;
    b = b.x;
    c = c.x;
    d = d.x;

	// Lets expand this 
    // x = a * (1-t)� + b * 3 * (1-t)�t + c * 3 * (1-t)t� + d * t�
    //------------------------------------------------------------
    // x = a - 3at + 3at� - at� 
    //       + 3bt - 6bt� + 3bt�
    //             + 3ct� - 3ct�
    //                    + dt�
    //--------------------------------
    // x = - at�  + 3bt� - 3ct� + dt�
    //     + 3at� - 6bt� + 3ct�
    //     - 3at + 3bt
    //     + a
    //--------------------------------
    // 0 = t� (-a+3b-3c+d) +  => A
    //     t� (3a-6b+3c)   +  => B
    //     t  (-3a+3b)     +  => c
    //     a - x              => D
    //--------------------------------
    
    var A = d - 3*c + 3*b - a,
        B = 3*c - 6*b + 3*a,
        C = 3*b - 3*a,
        D = a-x;
        
    // So we need to solve At� + Bt� + Ct + D = 0     
    var t =  cubic(A,B,C,D); 
    
    // Replace the t on Bezier function and get x,y 
	var p = Bezier(p0,c0,c1,p1,t);
    
	return p;
}



/*
 * Bezier Function
 * Get X,Y by t 
 * Refer to https://pomax.github.io/bezierinfo/
 * @params a,b,c,d {x:x,y:y}
 * @params t is between 0-1
 * @return {{x:x on curve ,y:y on curve}}
 */
function Bezier(a,b,c,d,t){
	var point = {x:0,y:0},
        mt  = 1-t,
        mt2 = mt*mt,
        mt3 = mt2*mt;
        
	//fx(t) = x1 * (1-t)� + x2 * 3 * (1-t)�t + x3 * 3 * (1-t)t� + x4 * t�
	point.x = a.x*mt3 + b.x*3*mt2*t + c.x*3*mt*t*t + d.x*t*t*t;
    
    //fy(t) = y1 * (1-t)� + y2 * 3 * (1-t)�t + y3 * 3 * (1-t)t� + y4 * t�
	point.y = a.y*mt3 + b.y*3*mt2*t + c.y*3*mt*t*t + d.y*t*t*t;
    
	return point;
}

/*
 * Cubic Equation Calculator 
 * refer to http://www.1728.org/cubic.htm
 *
 * ax� + bx� + cx + d = 0 
 * @params a,b,c,d
 * @return x
 */
 
function cubic(a,b,c,d)
{
    var m,m2,k,n,n2,x,r,rc,theta,sign,dans;
    
    var f = eval(((3*c)/a) - (((b*b)/(a*a))))/3;
    var g = eval((2*((b*b*b)/(a*a*a))-(9*b*c/(a*a)) + ((27*(d/a)))))/27;
    var h = eval(((g*g)/4) + ((f*f*f)/27));

    if (h > 0) {
        
        m = eval(-(g/2)+ (Math.sqrt(h)));
        k = m < 0 ? -1:1;
        m2 = eval(Math.pow((m*k),(1/3)));
        m2 = m2*k;
        n = eval(-(g/2)- (Math.sqrt(h)));
        k = n<0 ? -1:1;
        n2 = eval(Math.pow((n*k),(1/3)));
        n2 = n2*k;
        x= eval ((m2 + n2) - (b/(3*a)));
        
    }else {
        r = (eval(Math.sqrt((g*g/4)-h)));
        k = r<0 ? -1:1;
        rc = Math.pow((r*k),(1/3))*k;
        theta = Math.acos((-g/(2*r)));
        x=eval (2*(rc*Math.cos(theta/3))-(b/(3*a)));
        x=x*1E+14;
        x=Math.round(x);
        x=(x/1E+14);
    }
    
    if ((f+g+h)==0)
    {
        if (d<0) {sign=-1}
        if (d>=0) {sign=1}
        if (sign>0){dans=Math.pow((d/a),(1/3));dans=dans*-1}
        if (sign<0){d=d*-1;dans=Math.pow((d/a),(1/3))}
        x=dans;
    }
    return x;
}